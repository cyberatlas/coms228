package edu.iastate.cs228.hw1;

/*
 * @author
*/

public class Sequence
{
  public char[] seqarr; // made public instead of protected for grading.

  public Sequence(char[] sarr)
  {
    // TODO
  }

  public int seqLength()
  {
    // TODO
  }
  
  public char[] getSeq()
  {
    // TODO
  }

  public String toString()
  {
    // TODO
  }

  public boolean equals(Object obj)
  { 
    // TODO
  }

  public boolean isValidLetter(char let)
  {
    // TODO
  }

}
