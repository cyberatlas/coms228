package edu.iastate.cs228.hw1;

/*
 * @author
*/

public class DNASequence extends Sequence
{
  public DNASequence(char[] dnaarr)
  {
    // TODO
  }

  @Override
  public boolean isValidLetter(char let)
  {
    // TODO
  }

  public char[] getReverseCompSeq()
  {
    // TODO
  }
 
  public void reverseComplement()
  {
    // TODO
  }
}
