package edu.iastate.cs228.hw1;

/*
 * @author
*/

public class GenomicDNASequence extends DNASequence
{
  public boolean[] iscoding; // made public instead of private for grading.

  public GenomicDNASequence(char[] gdnaarr)
  {
    // TODO
  }

  public void markCoding(int first, int last)
  {
    // TODO
  }

  public char[] extractExons(int[] exonpos)
  {
    // TODO
  }

}
